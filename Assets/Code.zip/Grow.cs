﻿using UnityEngine;

public class Grow
{
    public int seed_count = 0;
    public int terrarian_count = -1;
    public bool water = false;
}
